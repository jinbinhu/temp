# Scripts

The scripts directory contains various bash and python helper scripts.

| Script | Description |
|--|--|
| disable-icrc.sh | disables ICRC checking for a specific ibverbs device. <br/> <br/> This is needed for the client with rdma backend to work properly. Make sure to examine the script and customize it to your device name and your setup in general |
| enable-icrc.sh | enables ICRC checking back. |

