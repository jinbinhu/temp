
Welcome to SwitchML's documentation!
====================================

.. toctree::
   :maxdepth: 2

   Overview <readmes/overview>
   readmes/client_lib
   client_lib_api/client_lib_root
   readmes/p4
   readmes/controller
   readmes/examples
   readmes/benchmarks
   readmes/frameworks_integration
   readmes/scripts
   readmes/contrib
